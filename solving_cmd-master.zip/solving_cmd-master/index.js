console.log("プログラムを起動するためには，ターミナルから以下のように入力してください");
console.log("（ただし「>」はプロンプトを表すので入力しないこと）");
console.log("> node nibun.js");
console.log("　または");
console.log("> node newton.js");